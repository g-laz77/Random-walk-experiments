# Question 1

## Run program
python q1.py

## List of variables
- number = Max number of steps per person
- tc = number of times experiment is repeated
- origin = number of times they meet at the same place after the random walk
- one_x = x co-ordinate of 1st drunkard
- two_x = x co-ordinate of 2nd drunkard
- probability = probability of number of times they meet in a experiment with tc testcases