# Question 1

## Run program
python q2.py

## List of variables
- num_steps = Max number of steps per person
- num_drunk = number of drunk people
- radius = radius at which checked
- one_x = x co-ordinate of a drunkard
- one_y = y co-ordinate of a  drunkard
- one_z = z co-ordinate of a drunkard
- mod = modulus of the vector position of a drunk